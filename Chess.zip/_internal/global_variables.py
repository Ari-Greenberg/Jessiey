global white_king_moved
global white_rk_moved # This is the rook on the shorter side when castling
global white_rq_moved # This is the rook on the longer side when castling

global black_king_moved
global black_rk_moved
global black_rq_moved

white_king_moved = False
white_rk_moved = False
white_rq_moved = False

black_king_moved = False
black_rk_moved = False
black_rq_moved = False